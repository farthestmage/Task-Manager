

class TaskNotFoundError(Exception):
    pass