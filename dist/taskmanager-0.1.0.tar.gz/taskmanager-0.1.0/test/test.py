'''
task-cli add "NAME_TASK"

task-cli update task_id "NEW_NAME_TASK"

task-cli list all
task-cli list todo
task-cli list done

task-cli mark-done
task cli mark-in-progress

'''