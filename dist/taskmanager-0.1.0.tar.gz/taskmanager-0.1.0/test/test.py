'''
task-cli add "NAME_TASK"

task-cli update task_id "NEW_NAME_TASK"
task-cli delete task_id

task-cli list 
task-cli list todo
task-cli list done

task-cli mark-done
task cli mark-in-progress

'''